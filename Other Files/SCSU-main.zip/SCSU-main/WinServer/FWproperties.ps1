netsh advfirewall set publicprofile firewallpolicy 'blockinbound,blockoutbound'
netsh advfirewall set domainprofile firewallpolicy 'blockinbound,blockoutbound'
netsh advfirewall set privateprofile firewallpolicy 'blockinbound,blockoutbound'
netsh advfirewall set allprofiles settings unicastresponsetomulticast disable

netsh advfirewall firewall add rule name="TCP allow http" dir=out action=allow protocol=TCP localport=80
netsh advfirewall firewall add rule name="TCP allow https" dir=out action=allow protocol=TCP localport=443
netsh advfirewall firewall add rule name="UDP allow http" dir=out action=allow protocol=UDP localport=80
netsh advfirewall firewall add rule name="UDP allow https" dir=out action=allow protocol=UDP localport=443
netsh advfirewall firewall add rule name="UDP allow DNS" dir=out action=allow protocol=UDP localport=53
