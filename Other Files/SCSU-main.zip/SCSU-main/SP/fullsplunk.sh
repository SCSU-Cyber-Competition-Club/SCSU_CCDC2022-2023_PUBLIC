#!/bin/bash

sudo iptables -F
sudo iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
sudo iptables -A INPUT -p tcp -m multiport --dport 80,443,8000,514,8089,9997 -m conntrack --ctstate ESTABLISHED -j ACCEPT
sudo iptables -A OUTPUT -m conntrack --ctstate ESTABLISHED -j ACCEPT
sudo iptables -A OUTPUT -p tcp -m multiport --dport 80,443,514,9997,8000,8089 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
sudo iptables -A OUTPUT -p udp --dport 53 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
sudo iptables -A INPUT -i lo -j ACCEPT
sudo iptables -A OUTPUT -o lo -j ACCEPT
sudo iptables -A INPUT -m conntrack --ctstate INVALID -j DROP
sudo iptables -P INPUT DROP
sudo iptables -P FORWARD DROP
sudo iptables -P OUTPUT DROP


sudo yum update -y
sudo yum install nano vim iptables-services


cd /opt/splunk8/splunk/bin
./splunk stop

cd /opt/
mv /opt/splunk8/splunk/ /opt/splunk 
nano /opt/splunk/etc/splunk-launch.conf
./splunk start


cd /opt/splunk/bin 
./splunk set minfreemb 1000 

sudo iptables -F
sudo iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
sudo iptables -A INPUT -p tcp -m multiport --dport 80,443,8000,514,8089,9997 -m conntrack --ctstate ESTABLISHED -j ACCEPT
sudo iptables -A OUTPUT -m conntrack --ctstate ESTABLISHED -j ACCEPT
sudo iptables -A OUTPUT -p tcp -m multiport --dport 80,443,514,9997,8000,8089 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
sudo iptables -A OUTPUT -p udp --dport 53 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
sudo iptables -A INPUT -i lo -j ACCEPT
sudo iptables -A OUTPUT -o lo -j ACCEPT
sudo iptables -A INPUT -m conntrack --ctstate INVALID -j DROP
sudo iptables -P INPUT DROP
sudo iptables -P FORWARD DROP
sudo iptables -P OUTPUT DROP


sudo yum update -y
sudo yum install nano vim iptables-services


cd /opt/splunk8/splunk/bin
./splunk stop

cd /opt/
mv /opt/splunk8/splunk/ /opt/splunk 
nano /opt/splunk/etc/splunk-launch.conf
./splunk start


cd /opt/splunk/bin 
./splunk set minfreemb 1000 

su root << EOF
cd /opt/splunk/bin 
dcn-splunk-config 
dcn-network-config 
service network restart
EOF


sudo service chrond stop 
sudo service atd stop 
sudo service firewalld stop
sudo service firewalld disable
sudo systemctl disable firewalld

sudo -i << EOF
echo "WARNING! Access to this device is restricted to those individuals with specific
Permissions. If you are not an authorized user, disconnect now.
Any attempts to gain unauthorized access will be prosecuted to
the fullest extent of the law" >> /etc/issue
EOF
sudo service chrond stop 
sudo service atd stop 
sudo service firewalld stop
sudo service firewalld disable
sudo systemctl disable firewalld

sudo -i << EOF
echo "WARNING! Access to this device is restricted to those individuals with specific
Permissions. If you are not an authorized user, disconnect now.
Any attempts to gain unauthorized access will be prosecuted to
the fullest extent of the law" >> /etc/issue
EOF
