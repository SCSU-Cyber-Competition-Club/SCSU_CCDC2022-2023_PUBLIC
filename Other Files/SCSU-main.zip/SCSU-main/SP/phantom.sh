#!/bin/bash

sudo iptables -F
sudo iptables -A INPUT -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
sudo iptables -A OUTPUT -m conntrack --ctstate ESTABLISHED -j ACCEPT
sudo iptables -A INPUT -p tcp -m multiport --dports 80,443 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
sudo iptables -A OUTPUT -p tcp -m multiport --dports 443,80,9997 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
sudo iptables -A OUTPUT -p udp --dport 53 -m conntrack --ctstate NEW,ESTABLISHED -j ACCEPT
sudo iptables -A INPUT -i lo -j ACCEPT
sudo iptables -A OUTPUT -o lo -j ACCEPT
sudo iptables -A INPUT -m conntrack --ctstate INVALID -j DROP
sudo iptables -P INPUT DROP
sudo iptables -P FORWARD DROP
sudo iptables -P OUTPUT DROP

sudo -i << EOF
echo "WARNING! Access to this device is restricted to those individuals with specific
Permissions. If you are not an authorized user, disconnect now.
Any attempts to gain unauthorized access will be prosecuted to
the fullest extent of the law" >> /etc/issue
EOF

cd /opt/phantom/www
export PYTHONPATH=/opt/phantom/lib:/opt/phantom/www
phenv python manage.py changepassword admin

sudo systemctl stop chrond 
sudo systemctl stop atd 
sudo sysctl -w net.ipv6.conf.all.default.disable=1
sudo systemctl stop firewalld
sudo systemctl disable firewalld


sudo yum update -y
sudo yum install nano vim iptables-services
sudo yum groupinstall "KDE Plasma Workspaces" -y


startx
