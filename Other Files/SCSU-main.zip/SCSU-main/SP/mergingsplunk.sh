#!/bin/bash


cd /opt/splunk8/splunk/bin
./splunk stop

cd /opt/
mv /opt/splunk8/splunk/ /opt/splunk 
nano /opt/splunk/etc/splunk-launch.conf
./splunk start

