# SCSU
State and Regional ccdc for SCSU
to run a script in windows: 
Bat file: 
double click on the file or open terminal with admin privd. and type file location with the name

Powershell script: 
in a admin powershell window, go to file location .\*filename*

to run a script in Linux: go to file location chmod +x filename ./filename


Each Folder contains information/scripts for that specificed service
